class Juguete:
    __nombre = None
    __precio = 0
    
    def __init__(self):
        self.__nombre
        self.__precio
    
    def setNombre(self, nombre):
        self.__nombre = nombre
    
    def getNombre(self):
        return self.__nombre
    
    def setPrecio(self, precio):
        self.__precio = precio
        
    def getPrecio(self):
        return self.__precio
    
