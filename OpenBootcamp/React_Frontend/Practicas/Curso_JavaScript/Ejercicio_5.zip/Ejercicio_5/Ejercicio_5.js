let altura_1 = 169;
let altura_2 = altura_1 / 100;
let peso = 59.8;
let altura_redondeada = Math.ceil(altura_2);
let peso_redondeado = Math.floor(peso);
let max_1 = Number.MAX_VALUE + 1;
let max_2 = Number.MAX_VALUE;

console.log(altura_1);
console.log(altura_2);
console.log(peso);
console.log(altura_redondeada);
console.log(peso_redondeado);
console.log(max_1);
console.log(max_2);

if (max_1 === max_2) {
    console.log(`${max_1} y ${max_2} son iguales.`);
} else {
    console.log(`${max_1} y {max_2} no son iguales.`);
}
